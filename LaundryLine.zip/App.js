import * as React from 'react';
import { ScrollView, View } from 'react-native';
import AppNavigator from './AppNavigator.js';
//import AllDryersAndWashers from './allDryersAndWashers.js';

function App() {
  return (
  <AppNavigator/>
  );
}


export default App;