import * as React from 'react';
import { View, Text, StyleSheet, Image, TextInput } from 'react-native';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import WasherDryerScreen from './WasherDryerScreen';
import { Button } from 'react-native-elements';

const Stack = createStackNavigator();

const styles = StyleSheet.create({
  screenText: {
      flex: 1,
      alignItems: 'center',
      backgroundColor: 'rgb(124, 102, 154 )',
      justifyContent: 'center'
  }
});

class AppNavigator extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      code: ''
    };
  }

    MyTheme = {
      ...DefaultTheme,
      colors: {
          primary: 'rgb(255, 45, 85)',
          background: 'rgb(242, 242, 242)',
          card: 'rgb(255, 255, 255)',
          text: 'rgb(28, 28, 30)',
          border: 'rgb(199, 199, 204)',
      },
    };

    SignupScreen({ navigation }) {
      return (
          <KeyboardAwareScrollView
          contentContainerStyle={styles.screenText}
          resetScrollToCoords={{ x: 0, y: 0 }}
          scrollEnabled={false}
          >
          <Text style = {{color:"white", fontSize: 25, fontWeight: "bold"}}> Sign Up </Text>
          <View style = {{paddingBottom: 10, paddingTop: 20}}>      
          <TextInput
          style={{width: 200, height: 40, borderRadius: 20, borderWidth: 2, borderColor: "white", color: "white"}}
          placeholder = "  Username"
          placeholderTextColor = "white"/>
          </View>
          <View style = {{paddingBottom: 10, paddingTop: 10, paddingBottom: 15}}>      
          <TextInput
          secureTextEntry = {true}
          password = {true}
          style={{width: 200, height: 40, borderRadius: 20, borderWidth: 2, borderColor: "white", color: "white", paddingLeft: 5}}
          placeholder = " Password"
          placeholderTextColor = "white"/>
          </View>
          <View style = {{paddingBottom: 10, paddingTop: 8, paddingBottom: 15}}>      
          <TextInput
          style={{ width: 200, height: 40, borderRadius: 20, borderWidth: 2, borderColor: "white", color: "white"}}
          placeholder = "  Special Code"
          placeholderTextColor = "white"/>
          </View>
          <Button color = "white" title = "Create account!" style = {{width: 200, paddingTop: 8}}
          onPress={() => navigation.navigate('Washers and Dryers')}>
          </Button>
          </KeyboardAwareScrollView>
      );
    }

    HomeScreen({ navigation }) {
      return (
          <KeyboardAwareScrollView
          contentContainerStyle={styles.screenText}
          resetScrollToCoords={{ x: 0, y: 0 }}
          scrollEnabled={false}
        >
          <View style = {{paddingBottom: 20}}>
              <Image source = {require('./logo.png')} style = {{width: 180, height: 180, alignSelf: 'center'}}/>
          </View>
          <Text style = {{color: "white", fontSize: 25, fontWeight: "bold"}}>LaundryLine</Text>
          <View style = {{paddingBottom: 10, paddingTop: 20}}>      
            <TextInput
          style={{width: 200, height: 40, borderRadius: 20, borderWidth: 2, borderColor: "white", color: "white"}}
          placeholder = "  Username"
          placeholderTextColor = "white"/>
          </View>
          <View style = {{paddingBottom: 10, paddingTop: 10, paddingBottom: 15}}>      
          <TextInput
          secureTextEntry = {true}
          password = {true}
          style={{width: 200, height: 40, borderRadius: 20, borderWidth: 2, borderColor: "white", color: "white", paddingLeft: 5}}
          placeholder = " Password"
          placeholderTextColor = "white"/>
          </View>
          <Button color = "white" title = "Login" style = {{width: 200, paddingTop: 8}}
            onPress={() => navigation.navigate('Washers and Dryers')}>
          </Button>
          <View style = {{paddingTop: 18}}>
          <Text style = {{fontSize: 11, color:"white", textAlign: "center"}}> Don't have an account yet? </Text>
          <Text style={{fontSize: 11, color:"rgb(245,92,92)", textAlign: "center"}} onPress={()=> navigation.navigate('Sign Up')}> Sign Up </Text>
          </View>
        </KeyboardAwareScrollView>
      );
    }

    render() {
      return (
        <NavigationContainer theme = {this.MyTheme}>
          <Stack.Navigator initialRouteName="Home">
            <Stack.Screen name="Home" component={this.HomeScreen} />
            <Stack.Screen name="Washers and Dryers" component={WasherDryerScreen} />
            <Stack.Screen name="Sign Up" component={this.SignupScreen} />
          </Stack.Navigator>
        </NavigationContainer>
      );
    }
}

export default AppNavigator;


