import * as React from 'react';
import AllDryersAndWashers from './allDryersAndWashers.js';

export default function WasherDryerScreen({ navigation }) {
    return (
        <AllDryersAndWashers/>
    );
  }